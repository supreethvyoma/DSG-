﻿import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { useAuth } from "../../hooks/useAuth";
import { useCart } from "../../hooks/useCart";
import { useWishlist } from "../../hooks/useWishlist";
import { useDeliveryLocation } from "../../hooks/useDeliveryLocation";
import "./Navbar.css";

const onDemandUrl = String(
  import.meta.env.VITE_ONDEMAND_URL || (import.meta.env.DEV ? "http://localhost:5174/" : "")
).trim();

function Navbar() {
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const { wishlist } = useWishlist();
  const { selectedAddress, addresses, selectedIndex, selectAddress, addAddress, removeAddress, setDefaultAddress } =
    useDeliveryLocation();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isManagingAddresses, setIsManagingAddresses] = useState(false);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [locationStatusMessage, setLocationStatusMessage] = useState("");

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    const query = searchQuery.trim();
    navigate(query ? `/search?q=${encodeURIComponent(query)}` : "/search");
  };

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const queryFromUrl = params.get("q") || params.get("search") || "";
    if (location.pathname === "/" || location.pathname === "/search") {
      setSearchQuery(queryFromUrl);
    }
  }, [location.pathname, location.search]);

  useEffect(() => {
    setIsMenuOpen(false);
    setIsAddressModalOpen(false);
    setIsManagingAddresses(false);
    setIsDetectingLocation(false);
    setLocationStatusMessage("");
  }, [location.pathname, location.search]);

  useEffect(() => {
    if (isAddressModalOpen) return;
    setIsDetectingLocation(false);
    setLocationStatusMessage("");
  }, [isAddressModalOpen]);

  useEffect(() => {
    if (!isAddressModalOpen) return undefined;

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setIsAddressModalOpen(false);
      }
    };

    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isAddressModalOpen]);

  const linkClassName = ({ isActive }) =>
    `navbar-link navbar-outline${isActive ? " navbar-link-active" : ""}`;
  const activeAddress = selectedAddress || addresses[0] || null;
  const deliveryLine1 = "Deliver to";
  const deliveryLine2 = activeAddress
    ? activeAddress.address ||
      [activeAddress.city, activeAddress.state, activeAddress.pincode].filter(Boolean).join(", ") ||
      "Saved address"
    : "Select your address";

  const getAddressLocationText = (item) =>
    [item?.city, item?.state, item?.pincode, item?.country].filter(Boolean).join(", ");

  const getCurrentPosition = () =>
    new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation is not supported by this browser."));
        return;
      }

      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 12000
      });
    });

  const buildStreetAddress = (address = {}) => {
    const parts = [address?.house_number, address?.road, address?.neighbourhood, address?.suburb]
      .map((item) => String(item || "").trim())
      .filter(Boolean);
    return parts.join(", ");
  };

  const firstAddressValue = (address = {}, keys = []) => {
    for (const key of keys) {
      const value = String(address?.[key] || "").trim();
      if (value) return value;
    }
    return "";
  };

  const fetchAddressFromCoordinates = async (latitude, longitude) => {
    const params = new URLSearchParams({
      lat: String(latitude),
      lon: String(longitude),
      format: "jsonv2",
      addressdetails: "1"
    });

    const response = await fetch(`https://nominatim.openstreetmap.org/reverse?${params.toString()}`, {
      method: "GET",
      headers: {
        Accept: "application/json"
      }
    });

    if (!response.ok) {
      throw new Error("Could not resolve your location.");
    }

    const data = await response.json();
    const address = data?.address || {};
    const streetAddress = buildStreetAddress(address) || String(data?.name || "").trim();
    const city = firstAddressValue(address, ["city", "town", "village", "municipality", "county"]);
    const state = firstAddressValue(address, ["state", "region", "state_district"]);
    const pincode = firstAddressValue(address, ["postcode"]);
    const country = firstAddressValue(address, ["country"]) || "India";

    return {
      name: String(user?.name || "Current Location").trim(),
      phone: "",
      label: "Home",
      address: streetAddress || String(data?.display_name || "").trim() || "Current location",
      landmark: firstAddressValue(address, ["building", "amenity", "shop"]),
      city,
      state,
      pincode,
      country,
      latitude: Number(latitude),
      longitude: Number(longitude),
      isDefault: addresses.length === 0
    };
  };

  const handleUseCurrentLocation = async () => {
    if (isDetectingLocation) return;

    setIsDetectingLocation(true);
    setLocationStatusMessage("Detecting your current location...");

    try {
      const position = await getCurrentPosition();
      const latitude = Number(position?.coords?.latitude);
      const longitude = Number(position?.coords?.longitude);

      if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
        throw new Error("Could not read coordinates from your device.");
      }

      const payload = await fetchAddressFromCoordinates(latitude, longitude);
      addAddress(payload);
      setLocationStatusMessage("Current location saved as an address.");
    } catch (error) {
      setLocationStatusMessage(error?.message || "Could not use current location.");
    } finally {
      setIsDetectingLocation(false);
    }
  };

  return (
    <nav className="navbar">
      <div className="navbar-top">
        <div className="navbar-inner">
          <Link to="/" className="navbar-logo navbar-outline">
            <span className="navbar-logo-line1">digital</span>
            <span className="navbar-logo-line2">sanskrit guru</span>
          </Link>

          <button
            type="button"
            className="navbar-location navbar-location-btn navbar-outline"
            onClick={() => setIsAddressModalOpen(true)}
          >
            <span className="navbar-location-icon" aria-hidden="true">
              📍
            </span>
            <span className="navbar-location-text">
              <span className="navbar-location-label">{deliveryLine1}</span>
              <span className="navbar-location-value">{deliveryLine2}</span>
            </span>
          </button>

          <form className="navbar-search-wrap" onSubmit={handleSearchSubmit}>
            <input
              className="navbar-search"
              placeholder="Search products, courses, and topics"
              aria-label="Search products, courses, and topics"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button type="submit" className="navbar-search-btn" aria-label="Search">
              <span className="navbar-search-btn-icon" aria-hidden="true">
                🔍
              </span>
              <span className="navbar-search-btn-text">Search</span>
            </button>
          </form>

          <div className="navbar-right">
            {user ? (
              <Link className="navbar-account navbar-outline" to="/account">
                <span className="navbar-account-line1">Hello, {user.name}</span>
                <span className="navbar-account-line2">Your Account</span>
              </Link>
            ) : (
              <Link className="navbar-account navbar-outline" to="/login">
                <span className="navbar-account-line1">Hello, Sign in</span>
                <span className="navbar-account-line2">Account & Lists</span>
              </Link>
            )}

            <Link className="navbar-orders navbar-outline" to="/my-orders">
              <span className="navbar-account-line1">Returns</span>
              <span className="navbar-account-line2">& Orders</span>
            </Link>

            <Link className="navbar-cart navbar-outline" to="/cart">
              <span className="navbar-cart-icon" aria-hidden="true">
                🛒
              </span>
              <span className="navbar-cart-label">Cart</span>
              <span className="navbar-badge">{cartItems.length}</span>
            </Link>

            <button
              type="button"
              className="navbar-menu-toggle navbar-outline"
              aria-expanded={isMenuOpen}
              aria-controls="navbar-subbar-links"
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
              onClick={() => setIsMenuOpen((current) => !current)}
            >
              <span className="navbar-menu-icon" aria-hidden="true">
                <span />
                <span />
                <span />
              </span>
              <span className="navbar-menu-text">{isMenuOpen ? "Close" : "Menu"}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="navbar-attached-bar">
        <div className="navbar-inner navbar-attached-bar-inner">
          <Link
            to="/collection"
            className="navbar-ondemand-btn"
            aria-label="Open all collection"
          >
            All Collection
          </Link>
          {onDemandUrl ? (
            <a
              href={onDemandUrl}
              className="navbar-ondemand-btn"
              target="_blank"
              rel="noreferrer"
              aria-label="Ondemand website"
            >
              Open OnDemand
            </a>
          ) : null}
        </div>
      </div>
      {isMenuOpen && (
        <button
          type="button"
          className="navbar-menu-backdrop"
          aria-label="Close navigation menu"
          onClick={() => setIsMenuOpen(false)}
        />
      )}

      <div className={`navbar-subbar ${isMenuOpen ? "navbar-subbar-open" : ""}`}>
        <div className="navbar-inner navbar-subbar-inner" id="navbar-subbar-links">
          <button
            type="button"
            className="navbar-mobile-location"
            onClick={() => setIsAddressModalOpen(true)}
          >
            {deliveryLine1} <strong>{deliveryLine2}</strong>
          </button>

          <NavLink className={linkClassName} to="/" end>
            Home
          </NavLink>
          <NavLink className={linkClassName} to="/wishlist">
            Wishlist <span className="navbar-inline-count">{wishlist.length}</span>
          </NavLink>
          <NavLink className={linkClassName} to="/my-orders">
            My Orders
          </NavLink>
          {user ? (
            <NavLink className={linkClassName} to="/account">
              My Account
            </NavLink>
          ) : (
            <NavLink className={linkClassName} to="/login">
              Login
            </NavLink>
          )}
          {user?.isAdmin && (
            <NavLink className={linkClassName} to="/admin">
              Admin Dashboard
            </NavLink>
          )}
          {user ? (
            <button type="button" className="navbar-link navbar-logout navbar-outline" onClick={logout}>
              Sign Out
            </button>
          ) : (
            <NavLink className={linkClassName} to="/register">
              New Customer? Register
            </NavLink>
          )}
        </div>
      </div>

      {isAddressModalOpen && (
        <div
          className="navbar-address-modal-backdrop"
          onClick={() => setIsAddressModalOpen(false)}
          role="presentation"
        >
          <div
            className="navbar-address-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="navbar-address-modal-title"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="navbar-address-modal-head">
              <h3 id="navbar-address-modal-title">
                <span className="navbar-address-modal-head-icon" aria-hidden="true">
                  📍
                </span>
                Select delivery address
              </h3>
              <button type="button" onClick={() => setIsAddressModalOpen(false)}>
                Close
              </button>
            </div>

            <div className="navbar-address-current-location">
              <button
                type="button"
                className="navbar-address-current-location-btn"
                onClick={handleUseCurrentLocation}
                disabled={isDetectingLocation}
              >
                {isDetectingLocation ? "Fetching location..." : "Use Current Location"}
              </button>
              {locationStatusMessage ? (
                <p className="navbar-address-current-location-note">{locationStatusMessage}</p>
              ) : null}
            </div>

            {addresses.length > 0 ? (
              <div className="navbar-address-options">
                {addresses.map((item, index) => (
                  <article
                    key={`${item.name}-${item.pincode}-${index}`}
                    className={selectedIndex === index ? "navbar-address-option active" : "navbar-address-option"}
                  >
                    <div className="navbar-address-option-top">
                      <label className="navbar-address-radio">
                        <input
                          type="radio"
                          name="navbar-selected-address"
                          checked={selectedIndex === index}
                          onChange={() => selectAddress(index)}
                        />
                        <strong>{item.name || "Address"}</strong>
                      </label>
                      <span>{item.label || "Saved address"}</span>
                    </div>
                    {item.phone ? <p>{item.phone}</p> : null}
                    <p>{item.address}</p>
                    <p>{getAddressLocationText(item) || "Location details not available"}</p>
                    {item.isDefault ? <span className="navbar-address-default-pill">Default address</span> : null}

                    <div className="navbar-address-option-actions">
                      {selectedIndex !== index ? (
                        <button
                          type="button"
                          className="navbar-address-action primary"
                          onClick={() => {
                            selectAddress(index);
                            setIsAddressModalOpen(false);
                          }}
                        >
                          Deliver to this address
                        </button>
                      ) : (
                        <span className="navbar-address-selected-pill">Currently selected</span>
                      )}
                      {!item.isDefault ? (
                        <button
                          type="button"
                          className="navbar-address-action"
                          onClick={() => {
                            setDefaultAddress(index);
                          }}
                        >
                          Set Default
                        </button>
                      ) : null}
                      {isManagingAddresses ? (
                        <button
                          type="button"
                          className="navbar-address-action danger"
                          onClick={() => {
                            removeAddress(index);
                          }}
                        >
                          Delete
                        </button>
                      ) : null}
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <p className="navbar-address-empty">No saved address yet. Add one to enable quick selection.</p>
            )}

            <div className="navbar-address-modal-actions">
              <Link to="/account?openAddressForm=1#manage-address" onClick={() => setIsAddressModalOpen(false)}>
                Add Address
              </Link>
              <button type="button" onClick={() => setIsManagingAddresses((current) => !current)}>
                {isManagingAddresses ? "Done Managing" : "Manage Addresses"}
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

export default Navbar;
